import express from "express";
import * as gameController from "../controllers/gameController";
import { validateGame } from "../middlewares/validate";

const router = express.Router();

router.get("/games", gameController.getAllGames);
router.get("/games/:id", gameController.getGameById);
router.post("/games", validateGame, gameController.createGame);
router.put("/games/:id", validateGame, gameController.updateGame);
router.delete("/games/:id", gameController.deleteGame);

export default router;
