export interface Game {
  id: string;
  title: string;
  genre: string;
  releaseYear: number;
}
