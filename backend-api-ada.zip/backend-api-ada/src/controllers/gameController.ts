import { Request, Response } from "express";
import { Game } from "../models/game";

let games: Game[] = [];

export const getAllGames = (req: Request, res: Response) => {
  res.json(games);
};

export const getGameById = (req: Request, res: Response) => {
  const { id } = req.params;
  const game = games.find((game) => game.id === id);
  if (!game) {
    res.status(404).json({ message: "Game not found" });
  } else {
    res.json(game);
  }
};

export const createGame = (req: Request, res: Response) => {
  const { title, genre, releaseYear } = req.body;
  const id = Math.random().toString(36).substr(2, 9);
  const newGame: Game = { id, title, genre, releaseYear };
  games.push(newGame);
  res.status(201).json(newGame);
};

export const updateGame = (req: Request, res: Response) => {
  const { id } = req.params;
  const { title, genre, releaseYear } = req.body;
  const index = games.findIndex((game) => game.id === id);
  if (index === -1) {
    res.status(404).json({ message: "Game not found" });
  } else {
    games[index] = { id, title, genre, releaseYear };
    res.json(games[index]);
  }
};

export const deleteGame = (req: Request, res: Response) => {
  const { id } = req.params;
  const index = games.findIndex((game) => game.id === id);
  if (index === -1) {
    res.status(404).json({ message: "Game not found" });
  } else {
    games.splice(index, 1);
    res.status(204).send();
  }
};
