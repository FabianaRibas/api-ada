import { Request, Response, NextFunction } from "express";

export const validateGame = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { title, genre, releaseYear } = req.body;
  if (!title || !genre || !releaseYear) {
    return res
      .status(400)
      .json({
        message:
          "Please provide the title, genre, and release year of the game",
      });
  }
  next();
};
